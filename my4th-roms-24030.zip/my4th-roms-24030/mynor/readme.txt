*******************************************************************************
**                                                                           **
**  This is the "cross over" My4TH ROM for the MyNOR computer board.         **
**                                                                           **
**  Platform :  MyNOR computer board                                         **
**  Version  :  1.4                                                          **
**  Developer:  Dennis Kuschel                                               **
**  eMail    :  dennis_k@freenet.de                                          **
**  Website  :  www.mynor.org/my4th                                          **
**                                                                           **
*******************************************************************************


This directory contains the EPROM image file for the MyNOR board.
The serial baud rate is 4800 baud if your MyNOR is clocked at 8 MHz.
You can also use the 8 MHz EPROM image for 4 MHz operation, but
please note that the baud rate will then be 2400 baud and that the
MS word will delay program execution twice as long.



Build Instructions
------------------

To build the source code, extract the source code archive,
change into the "source" directory and execute:
  
  # myca mynor-rom_8MHz.asm -o mynor-rom.bin -l

  
To generate the EPROM image file, execute:

  # my4th --uc-mynor -r mynor-rom.bin -w 0,0x7fff,mynor-rom_8MHz_v1.4.bin




My4TH for MyNOR ROM Version History
-----------------------------------

ROM v1.4
--------
  - fixed error handling in BLOCK words and in I2C-START word
  - fixed two minor bugs in the input-line routine (editor and command line)
  - fixed a bug in the 32-bit multiplication routine that only affected negative numbers
  - improved the output of "words", newly defined words are now printed last
  - improved the text editor, lines are edited inside the screen window now
  - added support for number prefixes [%#$], example: $14 = #20 = %10100
  - added support for underscore within numbers, example: %1001_0011

ROM v1.3
--------
  - fixed wrong behaviour of EVALUATE. Now it does no more print OK or COMPILED.
  - fixed a bug in the BLOAD word

ROM v1.2
--------
  - added new machine vector 5 as interface for external number parsers
  - added a progress display for the words BLOAD and LOAD-IMAGE

ROM v1.1
--------
  - fixed a bug that caused the word ROUT to return random values
  - changed the output format of WORDS

ROM v1.0
--------
  initial version
