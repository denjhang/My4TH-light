*******************************************************************************
**                                                                           **
**  This is the ROM for the yellow My4TH light board.                        **
**                                                                           **
**  Platform :  My4TH light computer board                                   **
**  Version  :  1.0                                                          **
**  Developer:  Dennis Kuschel                                               **
**  eMail    :  dennis_k@freenet.de                                          **
**  Website  :  www.mynor.org/my4th                                          **
**                                                                           **
*******************************************************************************


This directory contains the EPROM image file for the My4TH light board.
The serial baud rate is 4800 baud if your My4TH light is clocked at 8 MHz.



Build Instructions
------------------

To build the source code, extract the source code archive,
change into the "source" directory and execute:
  
  # myca my4th-light-rom.asm -o my4th-light.bin -l

  
To generate the EPROM image file, execute:

  # my4th --uc-xs -r my4th-light.bin -w 0,0x7fff,my4th-light-rom_v1.0.bin




My4TH light ROM Version History
-------------------------------

ROM v1.1
--------
  - fixed a bad bug in the floating point routines

ROM v1.0
--------
  initial version based on My4TH ROM v1.4
  additional new features:
  - much faster I2C bus
  - improved line editing at the command prompt (e.g. support for inserting characters)
  - improved built-in text editor
  additional features especially for My4TH light:
  - built-in word sets: floating point, string, facility
  - I2C support words for LCD, GPIO, UART, etc.
