*******************************************************************************
**                                                                           **
**  This is the original My4TH ROM for the My4TH board and the Forth Deck.   **
**                                                                           **
**  Platform :  My4TH board and Forth Deck                                   **
**  Version  :  1.4                                                          **
**  Developer:  Dennis Kuschel                                               **
**  eMail    :  dennis_k@freenet.de                                          **
**  Website  :  www.mynor.org/my4th                                          **
**                                                                           **
*******************************************************************************


This directory contains several EPROM image files. You must select the file
that matches the frequency of the oscillator on your board.

    my4th-rom_8MHz_v1.4.bin     -- binary My4TH EPROM image file for 8 MHz operation
    my4th-rom_10MHz_v1.4.bin    -- binary My4TH EPROM image file for 10 MHz operation
    my4th-rom_12MHz_v1.4.bin    -- binary My4TH EPROM image file for 12 MHz operation
    my4th-rom_14MHz_v1.4.bin    -- binary My4TH EPROM image file for 14 MHz operation



Build Instructions
------------------

To build the source code, extract the source code archive,
change into the "source" directory and execute:
  
  # myca my4th-rom_8MHz.asm -o my4th-rom.bin -l

  
To generate the EPROM image file, execute:

  # my4th -r my4th-rom.bin -w 0,0x7fff,my4th-rom_8MHz_v1.4.bin




My4TH ROM Version History
-------------------------

ROM v1.4
--------
  - fixed error handling in BLOCK words and in I2C-START word
  - fixed two minor bugs in the input-line routine (editor and command line)
  - fixed a bug in the 32-bit multiplication routine that only affected negative numbers
  - improved the output of "words", newly defined words are now printed last
  - improved the text editor, lines are edited inside the screen window now
  - added support for number prefixes [%#$], example: $14 = #20 = %10100
  - added support for underscore within numbers, example: %1001_0011
  - added new ROM-version for non Forth Deck devices with special features:
    the "nfd" version of the ROM compiles and executes Forth code much faster,
    it has a faster I2C bus and a better text editor.

ROM v1.3
--------
  - fixed wrong behaviour of EVALUATE. Now it does no more print OK or COMPILED.
  - fixed a bug in the BLOAD word

ROM v1.2
--------
  - added new machine vector 5 as interface for external number parsers
  - added a progress display for the words BLOAD and LOAD-IMAGE

ROM v1.1
--------
  - fixed a bug that caused the word ROUT to return random values
  - changed the output format of WORDS

ROM v1.0
--------
  initial version
