*******************************************************************************
**                                                                           **
**  This is the ROM for the red My4TH XS board.                              **
**                                                                           **
**  Platform :  My4TH XS computer board                                      **
**  Version  :  1.0                                                          **
**  Developer:  Dennis Kuschel                                               **
**  eMail    :  dennis_k@freenet.de                                          **
**  Website  :  www.mynor.org/my4th                                          **
**                                                                           **
*******************************************************************************


This directory contains the EPROM image file for the My4TH XS board.
The serial baud rate is 4800 baud if your My4TH XS is clocked at 8 MHz.



Build Instructions
------------------

To build the source code, extract the source code archive,
change into the "source" directory and execute:
  
  # myca my4th-xs-rom.asm -o my4th-xs.bin -l

  
To generate the EPROM image file, execute:

  # my4th --uc-xs -r my4th-xs.bin -w 0,0x3fff,my4th-xs-rom_v1.0.bin




My4TH XS ROM Version History
----------------------------

ROM v1.0
--------
  initial version based on My4TH ROM v1.4
